package com.darkdestiny.modelo.repositorios;

import org.springframework.data.jpa.repository.JpaRepository;


import com.darkdestiny.modelo.entidades.Asistente;

public interface AsistenteRepository extends JpaRepository<Asistente, Long> {

}