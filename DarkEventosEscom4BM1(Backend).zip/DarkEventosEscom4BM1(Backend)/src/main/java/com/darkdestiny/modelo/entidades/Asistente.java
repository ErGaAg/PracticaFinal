package com.darkdestiny.modelo.entidades;
import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
@Table(name = "Asistente", schema = "public")
public class Asistente implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "idAsistente", nullable = false)
	private Long idAsistente;
	
	@NotBlank(message = "no debe estar vacio ")
	@Size(min=4, max = 100, message = "El valor debe tener entre 4 y 100")
	@Column(name = "nombre", length = 100, nullable = false)
	private String nombre;
	
	@NotBlank(message = "no debe estar vacio ")
	@Size(min=4, max = 100, message = "El valor debe tener entre 4 y 100")
	@Column(name = "paterno", length = 100, nullable = false)
	private String paterno;
	
	@NotBlank(message = "no debe estar vacio ")
	@Size(min=4, max = 100, message = "El valor debe tener entre 4 y 100")
	@Column(name = "materno", length = 100, nullable = false)
	private String materno;
	

	@NotBlank(message = "no debe estar vacio ")
	@Size(min=4, max = 200, message = "El valor debe tener entre 4 y 200")
	@Email(message = "Agrega un correo electrónico ")
	@Column(name = "email", length = 200, nullable = false)
	private String email;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "fechaRegistro", nullable = false)
	private Date fechaRegistro;
	
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name="idEvento", nullable = false)
	@JsonProperty(access = Access.WRITE_ONLY)
	private Evento idEvento;
	

	public void setIdAsistente(Long idAsistente) {
		this.idAsistente = idAsistente;
		
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public void setPaterno(String paterno) {
		this.paterno = paterno;
	}
	
	public void setMaterno(String materno) {
		this.materno = materno;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public void setFechaRegistro(Date fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}
	
	public void setIdEvento(Evento idEvento) {
	    this.idEvento = idEvento;
	    if (idEvento != null) {
	        idEvento.getAsistentes().add(this);
	    }
	}

	public Long getIdAsistente() {
		return idAsistente;
	}

	public String getNombre() {
		return nombre;
	}

	public String getPaterno() {
		return paterno;
	}

	public String getMaterno() {
		return materno;
	}
	
	public String getEmail() {
		return email;
	}
	
	public Date getFechaRegistro() {
		return fechaRegistro;
	}
	
	public Evento getIdEvento() {
		return idEvento;
	}
}
