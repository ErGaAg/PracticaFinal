package com.darkdestiny.service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.List;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.darkdestiny.modelo.entidades.Evento;
import com.darkdestiny.modelo.repositorios.EventoRepository;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;


@Service
public class EventoServiceImpl implements EventoService{

	@Autowired
	EventoRepository eventoRepository;

	@Override
	@Transactional(readOnly = true)
	public List<Evento> findAll() {
		return (List<Evento>) eventoRepository.findAll();
	}

	@Override
	@Transactional(readOnly = true)
	public Evento findById(Long id) {
		return eventoRepository.findById(id).orElse(null);
	}

	@Override
	@Transactional
	public Evento save(Evento evento) {
		return eventoRepository.save(evento);
	}

	@Override
	@Transactional
	public void delete(Long id) {
		eventoRepository.deleteById(id);
	}

	@Override
	public ByteArrayInputStream reportePDF(List<Evento> listaDeEventos) {
		Document documento = new Document();
		ByteArrayOutputStream salida = new ByteArrayOutputStream();
		try {
			PdfWriter.getInstance(documento, salida);
			documento.open();
			Font tipoLetra = FontFactory.getFont(FontFactory.COURIER,16,BaseColor.BLUE);
			Paragraph parrafo = new Paragraph("Lista de Eventos",tipoLetra);
			parrafo.setAlignment(Element.ALIGN_CENTER);
			documento.add(parrafo);
			
			documento.add(Chunk.NEWLINE);
			Font textoFuente  = FontFactory.getFont(FontFactory.HELVETICA,10,BaseColor.BLUE);
			PdfPTable tabla = new PdfPTable(4);
			
			Stream.of("Clave del Evento", "Nombre del Evento",
					"Descripcion del Evento", " Fecha del Evento").
			forEach(
					headerTitle -> {
						PdfPCell encabezadoTabla = new PdfPCell();
						
						encabezadoTabla.setVerticalAlignment(Element.ALIGN_CENTER);
						encabezadoTabla.setHorizontalAlignment(Element.ALIGN_CENTER);
						encabezadoTabla.setBackgroundColor(BaseColor.CYAN);
						encabezadoTabla.setBorderWidth(1);
						encabezadoTabla.setPhrase(new Phrase(headerTitle, textoFuente));
						tabla.addCell(encabezadoTabla);
					}
					
					);
			for (Evento e : listaDeEventos) {
				PdfPCell celdaIdEvento = new PdfPCell(
						new Phrase(String.valueOf(e.getIdEvento()), textoFuente));
				celdaIdEvento.setPadding(1);
				celdaIdEvento.setVerticalAlignment(Element.ALIGN_CENTER);
				celdaIdEvento.setHorizontalAlignment(Element.ALIGN_CENTER);
				tabla.addCell(celdaIdEvento);
				
				PdfPCell celdaNombreEvento = new PdfPCell(
						new Phrase(String.valueOf(e.getNombreEvento()), textoFuente));
				celdaNombreEvento.setPadding(1);
				celdaNombreEvento.setVerticalAlignment(Element.ALIGN_CENTER);
				celdaNombreEvento.setHorizontalAlignment(Element.ALIGN_CENTER);
				tabla.addCell(celdaNombreEvento);
				
				PdfPCell celdaDescripcionEvento = new PdfPCell(
						new Phrase(String.valueOf(e.getDescripcionEvento()), textoFuente));
				celdaDescripcionEvento.setPadding(1);
				celdaDescripcionEvento.setVerticalAlignment(Element.ALIGN_CENTER);
				celdaDescripcionEvento.setHorizontalAlignment(Element.ALIGN_CENTER);
				tabla.addCell(celdaDescripcionEvento);
				
				PdfPCell celdaFechaEvento = new PdfPCell(
						new Phrase(String.valueOf(e.getFechaCreacion()), textoFuente));
				celdaFechaEvento.setPadding(1);
				celdaFechaEvento.setVerticalAlignment(Element.ALIGN_CENTER);
				celdaFechaEvento.setHorizontalAlignment(Element.ALIGN_CENTER);
				tabla.addCell(celdaFechaEvento);			
			}
			documento.add(tabla);
			documento.close();
			
		}catch (DocumentException e) {
			e.printStackTrace();
		}
		return new ByteArrayInputStream(salida.toByteArray());
	}


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
