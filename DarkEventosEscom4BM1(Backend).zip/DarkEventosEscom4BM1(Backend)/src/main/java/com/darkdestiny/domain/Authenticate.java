package com.darkdestiny.domain;

import org.springframework.stereotype.Service;

import com.darkdestiny.modelo.entidades.Mail;

@Service
public class Authenticate {
	
	Mail mail;
	
	public Authenticate(Mail mail) {
		this.mail = mail;
	}
	
	public void sendMessageUser(String email, String message) {
		mail.sendMessage(email, message);
	}

}
