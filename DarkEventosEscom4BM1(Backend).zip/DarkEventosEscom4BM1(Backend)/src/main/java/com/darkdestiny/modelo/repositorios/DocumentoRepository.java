package com.darkdestiny.modelo.repositorios;

import org.springframework.data.jpa.repository.JpaRepository;

import com.darkdestiny.modelo.entidades.Documento;

public interface DocumentoRepository 
     extends JpaRepository<Documento, Long> {

}