package com.darkdestiny.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.darkdestiny.modelo.entidades.Documento;
import com.darkdestiny.modelo.repositorios.DocumentoRepository;

@Service
public class DocumentoServicelmpl implements DocumentoService {

	@Autowired
	DocumentoRepository documentoRepository;
	
	@Override
	public Documento guardarArchivo(MultipartFile archivo) throws IOException{
	     String nombreDelArchivo =
	    		 StringUtils.cleanPath(archivo.getOriginalFilename());
	     Documento documento = Documento.builder()
	    		 .nombreDocumento(nombreDelArchivo)
	    		 .tipoDocumento(archivo.getContentType())
	    		 .datosDocumento(archivo.getBytes())
	    		 .build();
	     
	     return documentoRepository.save(documento);
	}
 
    @Override
    public Optional<Documento> descargarArchivo(Long id) throws FileNotFoundException {
        Optional<Documento> archivo = documentoRepository.findById(id);
        if(archivo.isPresent()) {
        	return archivo;
        }
        throw new FileNotFoundException("El archivo no existe");
    }
    
    @Override
    public boolean borrarArchivo(Long id) {
        Optional<Documento> documentoOptional = documentoRepository.findById(id);

        if (documentoOptional.isPresent()) {
            documentoRepository.deleteById(id);
            return true; // Borrado exitoso
        } else {
            return false; // No se encontró el archivo para borrar
        }
    }
}