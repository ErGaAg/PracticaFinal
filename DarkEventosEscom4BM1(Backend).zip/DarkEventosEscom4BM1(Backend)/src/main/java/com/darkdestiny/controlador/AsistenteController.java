package com.darkdestiny.controlador;

import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.darkdestiny.modelo.entidades.Asistente;
import com.darkdestiny.modelo.entidades.Evento;
import com.darkdestiny.service.AsistenteService;

import jakarta.validation.Valid;

@CrossOrigin(origins = { "http://localhost:4200" })
//@CrossOrigin(origins = {"*"})
@RestController
@RequestMapping("/apiEventos")
public class AsistenteController {
	@Autowired
	AsistenteService asistenteService;

	@GetMapping("/asistente")
	public List<Asistente> index() {
		return asistenteService.findAll();
	}
	
	@PostMapping("/crearAsistente")
	public List<Asistente> create() {
		return asistenteService.findAll();
	}
	
	@DeleteMapping("/EliminarAsistente")
	public List<Asistente> delete() {
		return asistenteService.findAll();
	}
	
	@PutMapping("/ActualizarAsistentes")
	public List<Asistente> update() {
		return asistenteService.findAll();
	}

	@GetMapping("/asistente/{id}")
	public ResponseEntity<?> read(@PathVariable Long id) {
		Asistente asistente = null;
		Map<String, Object> respuesta = new HashMap<>();
		try {
			asistente = asistenteService.findById(id);
		}catch (DataAccessException e) {
			respuesta.put("mensaje", "Error al realizar la consulta");
			respuesta.put("error", e.getMessage().concat(" = ")
					.concat(e.getMostSpecificCause().getMessage()));
			return new ResponseEntity<Map<String, Object>>(respuesta, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		if (asistente == null) {
			respuesta.put("mensaje", "El asistente". concat(id.toString()).concat(" no existe en la base de datos. "));
			return new ResponseEntity<Map<String, Object>>(respuesta, HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Asistente>(asistente, HttpStatus.OK);
	}
	
	@PostMapping("/asistente")
	public ResponseEntity<?> create(@Valid @RequestBody Asistente asistente, BindingResult resultado) {
		Asistente asistenteNuevo = null;
		Map<String, Object> respuesta = new HashMap<>();
		if (resultado.hasErrors()) {
			List<String> errores = resultado.getFieldErrors().stream()
					.map(err -> "El campo" + err.getField() + err.getDefaultMessage()).collect(Collectors.toList());
			respuesta.put("errores", errores);
			return new ResponseEntity<Map<String, Object>>(respuesta, HttpStatus.BAD_REQUEST);
		}
		
		try {
			asistenteNuevo = asistenteService.save(asistente);
		} catch (DataAccessException e) {
			respuesta.put("mensaje", "Error al insertar el asistente");
			respuesta.put("error", e.getMessage().concat(" = ").concat(e.getMostSpecificCause().getMessage()));
	        return new ResponseEntity<Map<String, Object>>(respuesta, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		respuesta.put("mensaje", "El asistente se creo satisfactoriamente");
		respuesta.put("asistente", asistenteNuevo);
		return new ResponseEntity<Map<String, Object>>(respuesta, HttpStatus.CREATED);
	}
	
	@PutMapping("/asistente/{id}")
	public ResponseEntity<?> update(@Valid @RequestBody Asistente asistente, BindingResult resultado, @PathVariable Long id) {
		Asistente asistenteActual = asistenteService.findById(id);
		Asistente asistenteActualizado = null;
		
		Map<String, Object> respuesta = new HashMap<>();
		
		if (resultado.hasErrors()) {
			List<String> errores = resultado.getFieldErrors().stream()
					.map(err -> "El campo" + err.getField() +" "+ err.getDefaultMessage()).collect(Collectors.toList());
			respuesta.put("errores", errores);
			return new ResponseEntity<Map<String, Object>>(respuesta, HttpStatus.BAD_REQUEST);
		}
		
		if (asistenteActual == null) {
			respuesta.put("mensaje", "Error al actualizar el asistente".concat(id.toString())
					.concat("no existe en la base de datos"));
			return new ResponseEntity<Map<String, Object>>(respuesta, HttpStatus.NOT_FOUND);
		}
		
		try {
			asistenteActual.setNombre(asistente.getNombre());
			asistenteActual.setPaterno(asistente.getPaterno());
			asistenteActual.setMaterno(asistente.getMaterno());
			asistenteActual.setEmail(asistente.getEmail());
			asistenteActual.setFechaRegistro(asistente.getFechaRegistro());
			
			asistenteActualizado = asistenteService.save(asistenteActual);
		} catch (DataAccessException e) {
			respuesta.put("mensaje", "Error al actualizar al asistente");
			respuesta.put("Error", e.getMessage().concat(" = ").concat(e.getMostSpecificCause().getMessage()));
			return new ResponseEntity<Map<String, Object>>(respuesta, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		respuesta.put("mensaje", "El asistente se actualizo satisfactoriamente");
		respuesta.put("asistente", asistenteActualizado);
		return new ResponseEntity<Map<String, Object>>(respuesta, HttpStatus.CREATED);
	}
	
	@DeleteMapping("/asistente/{id}")
	public ResponseEntity<?> delete(@PathVariable Long id){
		Map<String, Object> respuesta = new HashMap<>();
		try {
			asistenteService.delete(id);
		} catch (DataAccessException e) {
			respuesta.put("mensaje", "Error al eliminar al asistente");
			respuesta.put("error", e.getMessage().concat(" = ").concat(e.getMostSpecificCause().getMessage()));
			return new ResponseEntity<Map<String, Object>>(respuesta, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		respuesta.put("mensaje", "El asistente se eliminó satisfactoriamente");
		return new ResponseEntity<Map<String,Object >>(respuesta, HttpStatus.OK);
	}
	
	@GetMapping("/asistente/reportepdf")
	public ResponseEntity<InputStreamResource> generarPDF() {
		List<Asistente> listaDeAsistentes = (List<Asistente>) asistenteService.findAll();
		ByteArrayInputStream bais = asistenteService.reportePDF(listaDeAsistentes);
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "inline:filename=reporteEventos.pdf");
		return ResponseEntity.ok().headers(headers).contentType(MediaType.APPLICATION_PDF)
				.body(new InputStreamResource(bais));
	}
}

