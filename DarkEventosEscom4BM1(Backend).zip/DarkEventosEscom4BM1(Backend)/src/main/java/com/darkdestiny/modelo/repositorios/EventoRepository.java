package com.darkdestiny.modelo.repositorios;



import org.springframework.data.jpa.repository.JpaRepository;


import com.darkdestiny.modelo.entidades.Evento;

public interface EventoRepository extends JpaRepository<Evento, Long> {

}