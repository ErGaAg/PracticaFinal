package com.darkdestiny.service;

import java.io.ByteArrayInputStream;
import java.util.List;

import com.darkdestiny.modelo.entidades.Asistente;

public interface AsistenteService {
	public List<Asistente> findAll();
	public Asistente findById(Long id);
	public Asistente save(Asistente asistente);
	public void delete(Long id);
	
	
	public ByteArrayInputStream reportePDF(List<Asistente> listaDeAsistente);
}