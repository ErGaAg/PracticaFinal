package com.darkdestiny.controlador;

import java.io.ByteArrayInputStream;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.darkdestiny.modelo.entidades.Evento;
import com.darkdestiny.service.EventoService;

import jakarta.validation.Valid;

@CrossOrigin(origins = { "http://localhost:4200" })
//@CrossOrigin(origins = {"*"})
@RestController
@RequestMapping("/apiEventos")
public class EventoController {
	@Autowired
	EventoService eventoService;

	@GetMapping("/eventos")
	public List<Evento> index() {
		return eventoService.findAll();
	}
	
	@PostMapping("/crearEventos")
	public List<Evento> create() {
		return eventoService.findAll();
	}
	
	@DeleteMapping("/EliminarEventos")
	public List<Evento> delete() {
		return eventoService.findAll();
	}
	
	@PutMapping("/ActualizarEventos")
	public List<Evento> update() {
		return eventoService.findAll();
	}

	@GetMapping("/eventos/{id}")
	public ResponseEntity<?> read(@PathVariable Long id) {
		Evento evento = null;
		Map<String, Object> respuesta = new HashMap<>();
		try {
			evento = eventoService.findById(id);
		}catch (DataAccessException e) {
			respuesta.put("mensaje", "Error al realizar la consulta");
			respuesta.put("error", e.getMessage().concat(" = ")
					.concat(e.getMostSpecificCause().getMessage()));
			return new ResponseEntity<Map<String, Object>>(respuesta, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		if (evento == null) {
			respuesta.put("mensaje", "El evento". concat(id.toString()).concat(" no existe en la base de datos. "));
			return new ResponseEntity<Map<String, Object>>(respuesta, HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Evento>(evento, HttpStatus.OK);
	}
	
	@PostMapping("/eventos")
	public ResponseEntity<?> create(@Valid @RequestBody Evento evento, BindingResult resultado) {
		Evento eventoNuevo = null;
		Map<String, Object> respuesta = new HashMap<>();
		if (resultado.hasErrors()) {
			List<String> errores = resultado.getFieldErrors().stream()
					.map(err -> "El campo" + err.getField() + err.getDefaultMessage()).collect(Collectors.toList());
			respuesta.put("errores", errores);
			return new ResponseEntity<Map<String, Object>>(respuesta, HttpStatus.BAD_REQUEST);
		}
		
		try {
			eventoNuevo = eventoService.save(evento);
		} catch (DataAccessException e) {
			respuesta.put("mensaje", "Error al insertar el evento");
			respuesta.put("error", e.getMessage().concat(" = ").concat(e.getMostSpecificCause().getMessage()));
	        return new ResponseEntity<Map<String, Object>>(respuesta, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		respuesta.put("mensaje", "El evento se creo satisfactoriamente");
		respuesta.put("evento", eventoNuevo);
		return new ResponseEntity<Map<String, Object>>(respuesta, HttpStatus.CREATED);
	}
	
	@PutMapping("/eventos/{id}")
	public ResponseEntity<?> update(@Valid @RequestBody Evento evento, BindingResult resultado, @PathVariable Long id) {
		Evento eventoActual = eventoService.findById(id);
		Evento eventoActualizado = null;
		
		Map<String, Object> respuesta = new HashMap<>();
		
		if (resultado.hasErrors()) {
			List<String> errores = resultado.getFieldErrors().stream()
					.map(err -> "El campo" + err.getField() +" "+ err.getDefaultMessage()).collect(Collectors.toList());
			respuesta.put("errores", errores);
			return new ResponseEntity<Map<String, Object>>(respuesta, HttpStatus.BAD_REQUEST);
		}
		
		if (eventoActual == null) {
			respuesta.put("mensaje", "Error al actualizar el evento".concat(id.toString())
					.concat("no existe en la base de datos"));
			return new ResponseEntity<Map<String, Object>>(respuesta, HttpStatus.NOT_FOUND);
		}
		
		try {
			eventoActual.setNombreEvento(evento.getNombreEvento());
			eventoActual.setDescripcionEvento(evento.getDescripcionEvento());
			eventoActual.setFechaCreacion(evento.getFechaCreacion());
			
			eventoActualizado = eventoService.save(eventoActual);
		} catch (DataAccessException e) {
			respuesta.put("mensaje", "Error al actualizar el evento");
			respuesta.put("Error", e.getMessage().concat(" = ").concat(e.getMostSpecificCause().getMessage()));
			return new ResponseEntity<Map<String, Object>>(respuesta, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		respuesta.put("mensaje", "El evento se actualizo satisfactoriamente");
		respuesta.put("evento", eventoActualizado);
		return new ResponseEntity<Map<String, Object>>(respuesta, HttpStatus.CREATED);
	}
	
	@DeleteMapping("/eventos/{id}")
	public ResponseEntity<?> delete(@PathVariable Long id){
		Map<String, Object> respuesta = new HashMap<>();
		try {
			eventoService.delete(id);
		} catch (DataAccessException e) {
			respuesta.put("mensaje", "Error al eliminar el evento");
			respuesta.put("error", e.getMessage().concat(" = ").concat(e.getMostSpecificCause().getMessage()));
			return new ResponseEntity<Map<String, Object>>(respuesta, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		respuesta.put("mensaje", "El evento se eliminó satisfactoriamente");
		return new ResponseEntity<Map<String,Object >>(respuesta, HttpStatus.OK);
	}
	
	@GetMapping("/eventos/reportepdf")
	public ResponseEntity<InputStreamResource> genrarPDF() {
		List<Evento> listaDeEventos = (List<Evento>) eventoService.findAll();
		ByteArrayInputStream bais = eventoService.reportePDF(listaDeEventos);
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "inline:filename=reporteEventos.pdf");
		return ResponseEntity.ok().headers(headers).contentType(MediaType.APPLICATION_PDF)
				.body(new InputStreamResource(bais));
	}
	
}
