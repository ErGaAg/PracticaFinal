package com.darkdestiny.modelo.entidades;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class LoginRequest {
	
	private String emailUser;
	private String message;
	private String code;
	

	public String getEmailUser() {
		return emailUser;
	}

	public void setEmailUser(String emailUser) {
		this.emailUser = emailUser;
	}
	
	public String getMessage() {
		return message;
	}
	
	public void setMessage(String message) {
		this.message = message;
	}
	
	public String getCode() {
		return code;
	}
	
	public void setCode(String code) {
		this.code = code;
	}
}
