package com.darkdestiny.modelo.entidades;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table (name = "Documento")
public class Documento {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idDocumentos;

	private String nombreDocumento;
	private String tipoDocumento;
	@Lob
	@Column(length = 16777215)
	private byte[] datosDocumento;
	
	// Builder pattern
    public static Builder builder() {
        return new Builder();
    }
    
	public String getNombreDocumento() {
		return nombreDocumento;
	}

	public void setNombreDocumento(String nombreDocumento) {
		this.nombreDocumento = nombreDocumento;
	}

	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}
	
	public void setDatosDocumento(byte[] datosDocumento) {
		this.datosDocumento = datosDocumento;
	}

	public static class Builder {
        private Documento documento;

        private Builder() {
            this.documento = new Documento();
        }

        public Builder nombreDocumento(String nombreDocumento) {
            this.documento.setNombreDocumento(nombreDocumento);
            return this;
        }

        public Builder tipoDocumento(String tipoDocumento) {
            this.documento.setTipoDocumento(tipoDocumento);
            return this;
        }

        public Builder datosDocumento(byte[] datosDocumento) {
            this.documento.datosDocumento = datosDocumento;
            return this;
        }

        public Documento build() {
            return this.documento;
        }
    }

	public byte[] getDatosDocumento() {
        return datosDocumento;
    }

	public Object getId() {
		return idDocumentos;
	}
}
