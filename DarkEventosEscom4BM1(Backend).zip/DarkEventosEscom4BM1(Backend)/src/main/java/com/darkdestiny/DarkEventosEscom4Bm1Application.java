package com.darkdestiny;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DarkEventosEscom4Bm1Application {

	public static void main(String[] args) {
		SpringApplication.run(DarkEventosEscom4Bm1Application.class, args);
	}

}
