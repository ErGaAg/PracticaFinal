package com.eventosEscom.eventosEscom;

import java.util.List;

import org.springframework.data.repository.Repository;


public interface EventoRepositorio extends Repository<Evento, Integer>{
    
 
    List<Evento>findAll();
    Evento findOne(int id);
    Evento save(Evento p);
    void delete(Evento p);
    
}