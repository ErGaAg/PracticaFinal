package com.darkdestiny;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DarkEventosEscom4Bm1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
