package com.eventosEscom.eventosEscom;

import java.util.List;

public interface EventoService {

    List<Evento>ver();
    Evento verEvento(int id);
    Evento agregar(Evento p);
    Evento editar(Evento p);
    Evento borrar(int id);
    
}
