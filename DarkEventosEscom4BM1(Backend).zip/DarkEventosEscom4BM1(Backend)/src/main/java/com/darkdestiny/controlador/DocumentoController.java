package com.darkdestiny.controlador;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Optional;
import java.util.Base64;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.darkdestiny.modelo.entidades.Documento;
import com.darkdestiny.service.DocumentoService;
import com.ipn.mx.dto.respuestaDTO;

@RestController
@RequestMapping("/apiEventos")
public class DocumentoController {
		@Autowired
		DocumentoService documentoService;
		
		@PostMapping("/subirArchivo")
		public ResponseEntity<respuestaDTO> subirArchivo
		(@RequestParam ("archivo") MultipartFile archivo) throws IOException{
			documentoService.guardarArchivo(archivo);
			return ResponseEntity.status(HttpStatus.OK).
					body(new respuestaDTO("Archivo subido satisfactoriamente"));
		}
		
		@GetMapping("/asistente/mostrarArchivo/{id}")
		public ResponseEntity<byte[]> descargaDocumento(@PathVariable Long id)
		throws FileNotFoundException{
			Documento documento = documentoService.descargarArchivo(id).get();
			return ResponseEntity.status(HttpStatus.OK)
					.header(HttpHeaders.CONTENT_TYPE, documento.getTipoDocumento())
					.header(HttpHeaders.CONTENT_DISPOSITION,
							"attachment: filename=\""
							+ documento.getNombreDocumento() +
							"\""
							).body(documento.getDatosDocumento());
		}
		
		 @PutMapping("/actualizarArchivo/{id}")
		    public ResponseEntity<respuestaDTO> actualizarDocumento(
		            @PathVariable Long id,
		            @RequestParam("archivo") MultipartFile archivo) throws IOException {

		        // Validar si el documento existe
		        Optional<Documento> documentoExistente = documentoService.descargarArchivo(id);
		        if (documentoExistente.isEmpty()) {
		            return ResponseEntity.notFound().build();
		        }

		        // Obtener el documento existente
		        Documento documento = documentoExistente.get();

		        // Actualizar la información del documento
		        documento.setNombreDocumento(archivo.getOriginalFilename());
		        documento.setTipoDocumento(archivo.getContentType());
		        documento.setDatosDocumento(archivo.getBytes());

		        // Guardar el documento actualizado
		        documentoService.guardarArchivo(archivo);

		        return ResponseEntity.status(HttpStatus.OK)
		                .body(new respuestaDTO("Archivo actualizado satisfactoriamente"));
		    }
		
		 @DeleteMapping("/borrarArchivo/{id}")
		    public ResponseEntity<String> borrarDocumento(@PathVariable Long id) {
		        boolean borrado = documentoService.borrarArchivo(id);

		        if (borrado) {
		            return ResponseEntity.status(HttpStatus.OK).body("Archivo borrado satisfactoriamente");
		        } else {
		            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No se encontró el archivo para borrar");
		        }
		    }

	}