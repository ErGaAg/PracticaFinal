package com.darkdestiny.service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.List;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.darkdestiny.modelo.entidades.Asistente;
import com.darkdestiny.modelo.repositorios.AsistenteRepository;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;


@Service
public class AsistenteServicelmpl implements AsistenteService {

	@Autowired
	AsistenteRepository asistenteRepository;

	@Override
	@Transactional(readOnly = true)
	public List<Asistente> findAll() {
		return (List<Asistente>) asistenteRepository.findAll();
	}

	@Override
	@Transactional(readOnly = true)
	public Asistente findById(Long id) {
		return asistenteRepository.findById(id).orElse(null);
	}

	@Override
	@Transactional
	public Asistente save(Asistente asistente) {
		return asistenteRepository.save(asistente);
	}

	@Override
	@Transactional
	public void delete(Long id) {
		asistenteRepository.deleteById(id);
	}

	@Override
	public ByteArrayInputStream reportePDF(List<Asistente> listaDeAsistentes) {
		Document documento = new Document();
		ByteArrayOutputStream salida = new ByteArrayOutputStream();
		try {
			PdfWriter.getInstance(documento, salida);
			documento.open();
			Font tipoLetra = FontFactory.getFont(FontFactory.COURIER,16,BaseColor.BLUE);
			Paragraph parrafo = new Paragraph("Lista de Asistentes",tipoLetra);
			parrafo.setAlignment(Element.ALIGN_CENTER);
			documento.add(parrafo);
			
			documento.add(Chunk.NEWLINE);
			Font textoFuente  = FontFactory.getFont(FontFactory.HELVETICA,11,BaseColor.BLUE);
			PdfPTable tabla = new PdfPTable(6);
			
			Stream.of("Clave del Asistente", "Nombre del Asistente", "Apellido Paterno del Asistente", "Apellido Materno del Asistente",
					   "Email del asistente", "Fecha de registro").
			forEach(
					headerTitle -> {
						PdfPCell encabezadoTabla = new PdfPCell();
						
						encabezadoTabla.setVerticalAlignment(Element.ALIGN_CENTER);
						encabezadoTabla.setHorizontalAlignment(Element.ALIGN_CENTER);
						encabezadoTabla.setBackgroundColor(BaseColor.CYAN);
						encabezadoTabla.setBorderWidth(1);
						encabezadoTabla.setPhrase(new Phrase(headerTitle, textoFuente));
						tabla.addCell(encabezadoTabla);
					}
					
					);
			for (Asistente e : listaDeAsistentes) {
				PdfPCell celdaIdAsistente = new PdfPCell(
						new Phrase(String.valueOf(e.getIdAsistente()), textoFuente));
				celdaIdAsistente.setPadding(1);
				celdaIdAsistente.setVerticalAlignment(Element.ALIGN_CENTER);
				celdaIdAsistente.setHorizontalAlignment(Element.ALIGN_CENTER);
				tabla.addCell(celdaIdAsistente);
				
				PdfPCell celdaNombre = new PdfPCell(
						new Phrase(String.valueOf(e.getNombre()), textoFuente));
				celdaNombre.setPadding(1);
				celdaNombre.setVerticalAlignment(Element.ALIGN_CENTER);
				celdaNombre.setHorizontalAlignment(Element.ALIGN_CENTER);
				tabla.addCell(celdaNombre);
				
				PdfPCell celdaPaterno = new PdfPCell(
						new Phrase(String.valueOf(e.getPaterno()), textoFuente));
				celdaPaterno.setPadding(1);
				celdaPaterno.setVerticalAlignment(Element.ALIGN_CENTER);
				celdaPaterno.setHorizontalAlignment(Element.ALIGN_CENTER);
				tabla.addCell(celdaPaterno);
				
				PdfPCell celdaMaterno = new PdfPCell(
						new Phrase(String.valueOf(e.getMaterno()), textoFuente));
				celdaMaterno.setPadding(1);
				celdaMaterno.setVerticalAlignment(Element.ALIGN_CENTER);
				celdaMaterno.setHorizontalAlignment(Element.ALIGN_CENTER);
				tabla.addCell(celdaMaterno);
				
				PdfPCell celdaEmail = new PdfPCell(
						new Phrase(String.valueOf(e.getEmail()), textoFuente));
				celdaEmail.setPadding(1);
				celdaEmail.setVerticalAlignment(Element.ALIGN_CENTER);
				celdaEmail.setHorizontalAlignment(Element.ALIGN_CENTER);
				tabla.addCell(celdaEmail);
				
				PdfPCell celdaFechaRegistro = new PdfPCell(
						new Phrase(String.valueOf(e.getFechaRegistro()), textoFuente));
				celdaFechaRegistro.setPadding(1);
				celdaFechaRegistro.setVerticalAlignment(Element.ALIGN_CENTER);
				celdaFechaRegistro.setHorizontalAlignment(Element.ALIGN_CENTER);
				tabla.addCell(celdaFechaRegistro);
			}
			documento.add(tabla);
			documento.close();
			
		}catch (DocumentException e) {
			e.printStackTrace();
		}
		return new ByteArrayInputStream(salida.toByteArray());
	}

}

