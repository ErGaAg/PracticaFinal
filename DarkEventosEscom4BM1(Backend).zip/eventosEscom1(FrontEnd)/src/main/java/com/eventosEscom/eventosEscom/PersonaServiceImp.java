package com.eventosEscom.eventosEscom;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PersonaServiceImp  implements EventoService{
    @Autowired
    private EventoRepositorio repositorio;
    
    @Override
    public List<Evento> ver() {
        return repositorio.findAll();
    }

    @Override
    public Evento verEvento(int id) {
        return repositorio.findOne(id);
    }

    @Override
    public Evento agregar(Evento p) {
        return repositorio.save(p);
    }

    @Override
    public Evento editar(Evento p) {
        return repositorio.save(p);
    }

    @Override
    public Evento borrar(int id) {
        Evento p=repositorio.findOne(id);
        if(p!=null){
            repositorio.delete(p);
        }
       return p;
    }
    
    
    
}