package com.eventosEscom.eventosEscom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventosEscomApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventosEscomApplication.class, args);
	}

}
